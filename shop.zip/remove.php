<?php
include "cart/handler.php";
session_start();
if( isset($_GET['code']) and ctype_digit( $_GET['code'] ) )
{
  $cart = new \Cart\Handler;
  if($cart->removeItem( $_GET['code'] ) )
  {
      $_SESSION['message'] = "Item removed from cart";

      if(isset( $_GET['r'] ))
      {
        header("location: /shop/{$_GET['r']}");
        exit;
      }
      header("location: /shop");
      exit;
  }
}else
{
    header("location: /shop");
}