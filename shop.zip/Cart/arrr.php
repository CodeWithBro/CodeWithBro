<?php


  $name = 0 ? "names" : "gusrt";

  echo  $name;